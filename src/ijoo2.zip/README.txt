Inha Joo
CS411 HW4
MiniMax Algorithm - Tic Tac Toe

Instructions:

AIMA Code must be installed/referenced correctly.

1. When ran, put in initial board configurations.
Use b as blanks spaces.
The output will be coordinates, 0,0 being top left, 2,2 being bottom right.

Example:
Input:

X O

Output:

X O b
b b b
b b b

X playing...
(0,1) (0,2) (1,1)
