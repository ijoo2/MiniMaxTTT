package aima.core.logic.propositional.parsing.ast;

/**
 * @author Ravi Mohan
 * 
 */
public abstract class ComplexSentence extends Sentence {

}